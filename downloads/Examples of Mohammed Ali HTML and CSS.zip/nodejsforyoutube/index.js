const fs = require("fs");
// fs.writeFileSync('read.html', "<html><head><title> fff </title> </head> <body><h1>ggg</h1></body></html>");

const buf_data = fs.readFileSync("read.html");
console.log(buf_data);