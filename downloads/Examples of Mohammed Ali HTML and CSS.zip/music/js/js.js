const music = document.querySelector("audio");
const img = document.querySelector("img");
const play = document.getElementById("play");
const artist = document.getElementById("artist");
const title = document.getElementById("title");
const previous = document.getElementById("previous");
const next = document.getElementById("next");

// extracting songs

const songs = [
    {
        name: "018",
        title: "Surat Al-Kahf",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "081",
        title: "Surat Al-Takweer",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "082",
        title: "Surat Al-Enfetar",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "083",
        title: "Surat Al-Motafefeen",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "084",
        title: "Surat Al-Ensheqak",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "085",
        title: "Surat Al-Borooj",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "086",
        title: "Surat Al-Tarek",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "087",
        title: "Surat Al-Alaa",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "088",
        title: "Surat Al-Ghashiya",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "089",
        title: "Surat Al-Fajr",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "090",
        title: "Surat Al-Balad",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "091",
        title: "Surat Ash-Shams",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "092",
        title: "Surat Al-Layl",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "093",
        title: "Surat Ad-Duha",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "094",
        title: "Surat Al-shrah",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "095",
        title: "Surat At-Teen",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "096",
        title: "Surat Al-Alaq",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "097",
        title: "Surat Al-qadar",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "098",
        title: "Surat Al-Bayyinah",
        artist: "Maher Al-Moyqaly",
    },
    {
        name: "Alan-Walker-Faded",
        title: "Faded",
        artist: "Alan-Walker",
    },
];

let isPlaying = false;

// function play

const playMusic = () => {
    isPlaying = true;
    music.play();
    play.classList.replace("fa-play", "fa-pause");
    img.classList.add("anime");
};

//function pause

const pauseMusic = () => {
    isPlaying = false;
    music.pause();
    play.classList.replace("fa-pause", "fa-play");
    img.classList.remove("anime");
};

// turnery operator for play and pause

play.addEventListener("click", () => {
    isPlaying ? pauseMusic() : playMusic();
});


// changing the music data
const loadSong = (songs) => {
    title.textContent = songs.title;
    artist.textContent = songs.artist;
    music.src = "music/" + songs.name + ".mp3";
    img.src = "images/" + songs.name + ".jpg";
};

songIndex = 0;
// loadSong(songs[0]);
// define next function
const nextSong = () => {
    songIndex = (songIndex + 1) % songs.length;
    loadSong(songs[songIndex]);
    playMusic();
};
// define previous function 
const previousSong = () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSong(songs[songIndex]);
    playMusic();
};
next.addEventListener("click", nextSong);
previous.addEventListener("click", previousSong);